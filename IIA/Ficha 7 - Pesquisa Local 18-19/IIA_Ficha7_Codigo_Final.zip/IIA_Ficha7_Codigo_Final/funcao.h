int valida_solucao(int a[], int *mat, int vert);
int calcula_elementos(int a[], int vert);
